﻿/* exam.c
 * 入口主程序
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "ui.h"

int main(int argc, char *argv[])
{
    if (argc > 1) {
        // 调试模式
    }
    ui_index();
    return 0;
}
